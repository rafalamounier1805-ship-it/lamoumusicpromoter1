# LAMOU Ranking AI — MVP executável v1

Aplicativo web/PWA sem build obrigatório, desenhado para funcionar primeiro e aprofundar depois.

## O que funciona agora
- Dashboard simplificado e responsivo.
- Vistoria 1 pré-carregada para LAMOU.
- Spotify Artist ID pré-configurado: `1fEv1hrrhccjjUP3vpOQk4`.
- Ranking técnico da amostra processada.
- Catálogo preservado para faixas antigas ainda não reprocessadas.
- Sinais públicos Apple Music e Amazon Music.
- Perfil Spotify incorporado.
- Análise objetiva de áudio no navegador: duração, peak dBFS, RMS, crest factor, dinâmica aproximada, clipping.
- “Audio Readiness” local claramente separado do TQS artístico completo.
- Histórico pessoal persistente via localStorage.
- Salvar nova comparação sem sobrescrever as anteriores.
- Exportar/importar histórico JSON.
- Plano de ação persistente.
- PWA/offline após primeiro carregamento.
- Worker Cloudflare preparado para D1, cofre criptografado e Workers AI opcional.

## Rodar localmente
```bash
cd lamou-ranking-ai-v1
python3 -m http.server 4173 -d public
```
Abra `http://localhost:4173`.

## Verificar sintaxe
```bash
npm run check
```

## Cloudflare
A conta Cloudflare precisa ser autorizada uma única vez fora do código — isso não pode ser contornado de forma legítima. Depois da autorização:
1. copie `wrangler.example.jsonc` para `wrangler.jsonc`;
2. crie o D1 `lamou-ranking-ai` e deixe o Wrangler atualizar a configuração;
3. aplique `cloudflare/schema.sql`;
4. defina `ADMIN_SECRET` com `wrangler secret put ADMIN_SECRET`;
5. `wrangler deploy`.

O frontend funciona mesmo sem D1: o histórico cai automaticamente para armazenamento local, sem botão morto.

## Por que não há números inventados
Dados de plataforma são rotulados como verificados, limitados ou indisponíveis. O app não converte ausência de dados em estimativa silenciosa.
